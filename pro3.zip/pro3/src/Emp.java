//create table users(id number primary key,name varchar2(30),password varchar2(30),
//email varchar2(30),country varchar2(30))
public class Emp {

private String First_Name,Last_Name,Company_name,Email_Address,Phone,Address,Country,Apartment,City,District,Postcode;

public String getFirst_Name() {
	return First_Name;
}

public void setFirst_Name(String first_Name) {
	First_Name = first_Name;
}

public String getLast_Name() {
	return Last_Name;
}

public void setLast_Name(String last_Name) {
	Last_Name = last_Name;
}

public String getCompany_name() {
	return Company_name;
}

public void setCompany_name(String company_name) {
	Company_name = company_name;
}

public String getEmail_Address() {
	return Email_Address;
}

public void setEmail_Address(String email_Address) {
	Email_Address = email_Address;
}

public String getPhone() {
	return Phone;
}

public void setPhone(String phone) {
	Phone = phone;
}

public String getAddress() {
	return Address;
}

public void setAddress(String address) {
	Address = address;
}

public String getCountry() {
	return Country;
}

public void setCountry(String country) {
	Country = country;
}

public String getApartment() {
	return Apartment;
}

public void setApartment(String apartment) {
	Apartment = apartment;
}

public String getCity() {
	return City;
}

public void setCity(String city) {
	City = city;
}

public String getDistrict() {
	return District;
}

public void setDistrict(String district) {
	District = district;
}

public String getPostcode() {
	return Postcode;
}

public void setPostcode(String postcode) {
	Postcode = postcode;
}





}



