import java.sql.*;
import java.io.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
@WebServlet("/Checkout1")
public class Checkout1 extends HttpServlet
 {
Statement st=null;
Connection con=null;
ResultSet rs;
public void init()
{
System.out.println("init");
try
{
Class.forName("oracle.jdbc.driver.OracleDriver");
con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE","system","123456789");

}
catch(Exception ae)
{
}
}

    public void doGet(HttpServletRequest req, HttpServletResponse res)throws ServletException, IOException 
{
        res.setContentType("text/html");
        PrintWriter out = res.getWriter();
        out.println("<html>");
            out.println("<head>");
            out.println("<h1><center>CUSTOMER BILLING REPORT </h1><hr>");  
            out.println("</head>");
          out.println("<body bgcolor=white>");
 out.println("<img src=1.jpg>");
            out.println("<h3><center>CUSTOMER BILLING DETAILS</h3><hr>");
	out.println("<table border=2>");
 out.println("<tr>");
 out.print("<tr><th>First Name</th><th>Last Name</th><th>Company name</th><th>Email Address</th><th>Phone</th><th>Address</th><th>Country</th><th>Apartment</th><th>City</th><th>District</th><th>Postcode</th></tr>");
	 out.println("</tr>");
 try 
{

st=con.createStatement();
	
	rs=st.executeQuery("select * from users");

while(rs.next())
{
out.println("<tr><td>");
out.println(rs.getString(1));
out.println("<td>");
out.println(rs.getString(2));
out.println("<td>");
out.println(rs.getString(3));
out.println("<td>");
out.println(rs.getString(4));
out.println("<td>");
out.println(rs.getString(5));
out.println("<td>");
out.println(rs.getString(6));
out.println("<td>");
out.println(rs.getString(7));
out.println("<td>");
out.println(rs.getString(8));
out.println("<td>");
out.println(rs.getString(9));
out.println("<td>");
out.println(rs.getString(10));
out.println("<td>");
out.println(rs.getString(11));
out.println("</tr>");
}
}
catch(Exception at)
{}
           out.println("</body>");
            out.println("</html>");
    } 
public void destroy()
{
System.out.println("this is destroy");
}}