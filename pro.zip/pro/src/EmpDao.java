import java.util.*;
import java.sql.*;

public class EmpDao {

	public static Connection getConnection(){
		Connection con=null;
		try{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","123456789");
		}catch(Exception e){System.out.println(e);}
		return con;
	}
	public static int save(Emp e){
		int status=0;
		try{
			Connection con=EmpDao.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into users(First_Name,Last_Name,Company_name,Email_Address,Phone,Address,Country,Apartment,City,District,Postcode) values (?,?,?,?,?,?,?,?,?,?,?)");
			ps.setString(1,e.getFirst_Name());
			ps.setString(2,e.getLast_Name());
			ps.setString(3,e.getCompany_name());
			ps.setString(4,e.getEmail_Address());
			ps.setString(5,e.getPhone());
			ps.setString(6,e.getAddress());
			ps.setString(7,e.getCountry());
			ps.setString(8,e.getApartment());
			ps.setString(9,e.getCity());
			ps.setString(10,e.getDistrict());
			ps.setString(11,e.getPostcode());
			
			
			status=ps.executeUpdate();
			
			con.close();
		}catch(Exception ex){ex.printStackTrace();}
		
		return status;
	}
	
		
		
	}
