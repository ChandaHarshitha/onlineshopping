

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/EditServlet2")
public class EditServlet2 extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String FirstName=request.getParameter("t1");
		String LastName=request.getParameter("t2");
		String Companyname=request.getParameter("t3");
		String EmailAddress=request.getParameter("t4");
		String phone=request.getParameter("t5");
		String Address=request.getParameter("t6");
		String Country=request.getParameter("t7");
		String Apartment=request.getParameter("t8");
		String City=request.getParameter("t9");
		String District=request.getParameter("t10");
		String Postcode=request.getParameter("t11");
		
		
		Emp e=new Emp();
		e.setFirst_Name(FirstName);
		e.setLast_Name(LastName);
		e.setCompany_name(Companyname);
		e.setEmail_Address(EmailAddress);
		e.setPhone(phone);
		e.setAddress(Address);
		e.setCountry(Country);
		e.setApartment(Apartment);
		e.setCity(City);
		e.setDistrict(District);
		e.setPostcode(Postcode);
		
		
		
		int status=EmpDao.update(e);
		if(status>0){
			response.sendRedirect("ViewServlet");
		}else{
			out.println("Sorry! unable to update record");
		}
		
		out.close();
	}

}
