import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		out.println("<a href='index.html'>Add New Employee</a>");
		out.println("<h1>Employees List</h1>");
		
		List<Emp> list=EmpDao.getAllEmployees();
		
		out.print("<table border='1' width='100%'");
		out.print("<tr><th>First Name</th><th>Last Name</th><th>Company name</th><th>Email Address</th><th>Phone</th><th>Address</th><th>Country</th><th>Apartment</th><th>City</th><th>District</th><th>Postcode</th><th>Edit</th><th>Delete</th></tr>");
		for(Emp e:list){
			out.print("<tr><td>"+e.getFirst Name()+"</td><td>"+e.getLast Name()+"</td><td>"+e.getCompany name()+"</td><td>"+e.getEmail Address()+"</td><td>"+e.getPhone()+"</td><td>"+e.getAddress()+"</td><td>"+e.getCountry()+"</td><td>"+e.getApartment()+"</td><td>"+e.getCity()+"</td><td>"+e.getDistrict()+"</td><td>"+e.getPostcode()+"</td><td><a href='EditServlet?id="+e.getId()+"'>edit</a></td><td><a href='DeleteServlet?id="+e.getId()+"'>delete</a></td></tr>");
		}
		out.print("</table>");
		
		out.close();
	}
}
